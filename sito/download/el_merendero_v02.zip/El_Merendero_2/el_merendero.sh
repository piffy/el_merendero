#!/bin/sh

exec java -jar ./El_Merendero.jar
