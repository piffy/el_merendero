
package el_merendero;
import java.io.IOException;
import javax.swing.*;

/**
 *
 * @author b11g8
 */
public class El_Merendero {

    /**
     * Applicazione creata da Cagrandi,Bosi,Nizzoli,Galanti;
     * Applicazione riguardante la grafica del progetto.
     * Contiene un form iniziale con il concept della pagina iniziale con selezione ordine e classe.
     * 
     */
    public static void main(String[] args) throws IOException {
        Frame fr=new Frame();
        fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fr.setSize(800, 600);
        fr.setVisible(true);
    }
}
/*
 * El_Merendero. Questo programma permette all'utente di ordinare la merenda direttamente dalla propria classe.
 * Copyright (C) 2013  4B-INFO ITIS F.CORNI
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

                       GNU GENERAL PUBLIC LICENSE
                          Version 2, June 1991
 */