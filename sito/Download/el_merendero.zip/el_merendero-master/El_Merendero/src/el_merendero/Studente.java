/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package el_merendero;

/**
 *
 * @author charlie
 */
public class Studente {
    
    private String Nome_Cognome;

    public String getNome_Cognome() {
        return Nome_Cognome;
    }

    public void setNome_Cognome(String Nome_Cognome) {
        this.Nome_Cognome = Nome_Cognome;
    }

    public Studente(String Nome_Cognome) {
        this.Nome_Cognome = Nome_Cognome;
    }
    
    

    
    
    
}
